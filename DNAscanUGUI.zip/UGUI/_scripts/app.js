
//Wait for the document to load and for ugui.js to run before running your app's custom JS
$(document).ready( runApp );

//Container for your app's custom JS
function runApp() {





    //CUSTOM JS FOR YOUR APP GOES HERE





}// end runApp();
